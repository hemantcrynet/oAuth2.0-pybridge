import setuptools
setuptools.setup(
   name='pyoauthbridge',
   version='1.0.4',
   description='A useful module',
   long_description_content_type='text/x-rst',
   long_description='A project by tradelab',
   author='Biswajit',
   author_email='biswajit@tradelab.com',
   packages=["pyoauthbridge"]
)